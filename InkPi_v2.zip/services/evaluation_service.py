"""
InkPi 书法评测系统 - 评测服务

四维度评分（基于PDF算法研究文档）：
- 结构：字形匀称程度、凸包矩形度、留白分布
- 笔画：骨架提取分析、边缘复杂度
- 平衡：精确重心计算（公式化）、中轴线偏移量
- 韵律：行笔流畅度、连通性分析
"""
import numpy as np
import cv2
from typing import Dict, List, Tuple, Optional
import random
import logging
from pathlib import Path
from datetime import datetime

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from config import EVALUATION_CONFIG, FEEDBACK_TEMPLATES
from models.evaluation_result import EvaluationResult


class EvaluationService:
    """评测服务"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.config = EVALUATION_CONFIG
        self.dimensions = self.config["dimensions"]
        self.score_range = self.config["score_range"]
        
    def evaluate(
        self,
        processed_image: np.ndarray,
        original_image_path: str = None,
        processed_image_path: str = None,
        character_name: str = None
    ) -> EvaluationResult:
        """
        执行评测分析
        
        Args:
            processed_image: 预处理后的图像
            original_image_path: 原始图像路径
            processed_image_path: 处理后图像路径
            character_name: 字符名称
            
        Returns:
            EvaluationResult 评测结果
        """
        self.logger.info("开始评测分析...")
        
        # 计算四维评分
        detail_scores = self._calculate_scores(processed_image)
        
        # 计算总分
        total_score = sum(detail_scores.values()) // len(detail_scores)
        
        # 生成反馈
        feedback = self._generate_feedback(total_score, detail_scores)
        
        # 创建评测结果
        result = EvaluationResult(
            total_score=total_score,
            detail_scores=detail_scores,
            feedback=feedback,
            timestamp=datetime.now(),
            image_path=original_image_path,
            processed_image_path=processed_image_path,
            character_name=character_name
        )
        
        self.logger.info(f"评测完成: 总分={total_score}")
        return result
    
    def _calculate_scores(self, image: np.ndarray) -> Dict[str, int]:
        """
        计算四维评分
        
        Args:
            image: 预处理后的图像
            
        Returns:
            四维评分字典
        """
        # 确保是灰度图
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
            
        # 二值化（如果还不是）
        _, binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
        
        # 提取墨迹掩码
        ink_mask = binary == 0
        
        # 提取高级特征
        features = self._extract_advanced_features(binary, ink_mask)
        
        # 根据特征计算各维度分数
        scores = {}
        
        # 结构：基于凸包矩形度 + 弹性网格留白分析
        scores["结构"] = self._score_structure_advanced(features)
        
        # 笔画：基于骨架分析 + 边缘复杂度
        scores["笔画"] = self._score_stroke_advanced(features, binary)
        
        # 平衡：基于精确重心公式
        scores["平衡"] = self._score_balance_advanced(features)
        
        # 韵律：基于连通性 + 行笔流畅度
        scores["韵律"] = self._score_rhythm_advanced(features)
        
        return scores
    
    def _extract_advanced_features(self, binary: np.ndarray, ink_mask: np.ndarray) -> Dict[str, float]:
        """
        提取高级图像特征（基于PDF算法文档）
        
        Args:
            binary: 二值化图像
            ink_mask: 墨迹掩码
            
        Returns:
            特征字典
        """
        h, w = binary.shape
        total_pixels = binary.size
        ink_count = np.sum(ink_mask)
        
        features = {}
        
        # ============ 基础特征 ============
        features["ink_ratio"] = ink_count / total_pixels
        features["image_width"] = w
        features["image_height"] = h
        
        # ============ 1. 精确重心计算（PDF公式） ============
        # Gx = (1/N) * Σ(x * I(x,y)) / W
        # Gy = (1/N) * Σ(y * I(x,y)) / H
        if ink_count > 0:
            y_coords, x_coords = np.where(ink_mask)
            
            # 归一化重心坐标 (0-1范围)
            features["center_x"] = np.mean(x_coords) / w
            features["center_y"] = np.mean(y_coords) / h
            
            # 加权重心（考虑墨迹密度）
            weights = np.ones(len(x_coords))
            features["weighted_center_x"] = np.average(x_coords, weights=weights) / w
            features["weighted_center_y"] = np.average(y_coords, weights=weights) / h
        else:
            features["center_x"] = 0.5
            features["center_y"] = 0.5
            features["weighted_center_x"] = 0.5
            features["weighted_center_y"] = 0.5
        
        # 重心偏移量（到图像中心的距离）
        features["center_offset"] = np.sqrt(
            (features["center_x"] - 0.5) ** 2 + 
            (features["center_y"] - 0.5) ** 2
        )
        
        # ============ 2. 凸包矩形度分析 ============
        if ink_count > 0:
            # 提取墨迹轮廓
            contours, _ = cv2.findContours(
                (255 - binary).astype(np.uint8), 
                cv2.RETR_EXTERNAL, 
                cv2.CHAIN_APPROX_SIMPLE
            )
            
            if contours:
                # 合并所有轮廓点
                all_points = np.vstack(contours)
                
                # 计算凸包
                convex_hull = cv2.convexHull(all_points)
                hull_perimeter = cv2.arcLength(convex_hull, True)
                hull_area = cv2.contourArea(convex_hull)
                
                # 最小外接矩形
                min_rect = cv2.minAreaRect(convex_hull)
                rect_points = cv2.boxPoints(min_rect)
                rect_perimeter = 2 * (min_rect[1][0] + min_rect[1][1])
                
                # 凸包矩形度 = 凸包周长 / 外接矩形周长
                if rect_perimeter > 0:
                    features["convex_rectangularity"] = hull_perimeter / rect_perimeter
                else:
                    features["convex_rectangularity"] = 0.5
                    
                # 凸包面积与墨迹面积比
                if ink_count > 0:
                    features["hull_area_ratio"] = hull_area / ink_count
                else:
                    features["hull_area_ratio"] = 1.0
            else:
                features["convex_rectangularity"] = 0.5
                features["hull_area_ratio"] = 1.0
        else:
            features["convex_rectangularity"] = 0.5
            features["hull_area_ratio"] = 1.0
        
        # ============ 3. 弹性网格留白分析 ============
        grid_size = 3  # 3x3 网格
        cell_h, cell_w = h // grid_size, w // grid_size
        whitespace_ratios = []
        
        for i in range(grid_size):
            for j in range(grid_size):
                y1, y2 = i * cell_h, (i + 1) * cell_h
                x1, x2 = j * cell_w, (j + 1) * cell_w
                
                cell = ink_mask[y1:y2, x1:x2]
                cell_area = cell.size
                whitespace_ratio = 1 - (np.sum(cell) / cell_area)
                whitespace_ratios.append(whitespace_ratio)
        
        # 留白方差（越小越均匀）
        features["whitespace_variance"] = np.var(whitespace_ratios)
        features["whitespace_std"] = np.std(whitespace_ratios)
        
        # ============ 4. 骨架提取（Zhang-Suen算法） ============
        skeleton = self._extract_skeleton(binary)
        features["skeleton_length"] = np.sum(skeleton > 0)
        
        # 骨架分支点检测（笔画交叉点）
        branch_points = self._detect_branch_points(skeleton)
        features["branch_point_count"] = len(branch_points)
        
        # 端点检测
        end_points = self._detect_end_points(skeleton)
        features["end_point_count"] = len(end_points)
        
        # ============ 5. 连通分量分析 ============
        num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
            255 - binary, connectivity=8
        )
        features["num_components"] = num_labels - 1  # 排除背景
        
        # 最大连通分量占比
        if num_labels > 1:
            component_areas = stats[1:, cv2.CC_STAT_AREA]
            features["max_component_ratio"] = np.max(component_areas) / max(ink_count, 1)
            features["component_area_std"] = np.std(component_areas)
        else:
            features["max_component_ratio"] = 0
            features["component_area_std"] = 0
        
        # ============ 6. 边缘分析 ============
        edges = cv2.Canny(binary, 50, 150)
        features["edge_density"] = np.sum(edges > 0) / total_pixels
        
        # ============ 7. 投影分布 ============
        h_projection = np.sum(ink_mask, axis=1)  # 水平投影
        v_projection = np.sum(ink_mask, axis=0)  # 垂直投影
        
        h_mean = np.mean(h_projection) + 1e-6
        v_mean = np.mean(v_projection) + 1e-6
        
        features["h_proj_std"] = np.std(h_projection) / h_mean
        features["v_proj_std"] = np.std(v_projection) / v_mean
        
        # 投影对称性
        h_proj_norm = h_projection / (np.max(h_projection) + 1e-6)
        v_proj_norm = v_projection / (np.max(v_projection) + 1e-6)
        
        # 水平对称性
        h_flipped = np.flip(h_proj_norm)
        features["h_symmetry"] = 1 - np.mean(np.abs(h_proj_norm - h_flipped))
        
        # 垂直对称性
        v_flipped = np.flip(v_proj_norm)
        features["v_symmetry"] = 1 - np.mean(np.abs(v_proj_norm - v_flipped))
        
        self.logger.debug(f"特征提取完成: 重心=({features['center_x']:.3f}, {features['center_y']:.3f}), "
                         f"凸包矩形度={features['convex_rectangularity']:.3f}, "
                         f"留白方差={features['whitespace_variance']:.4f}")
        
        return features
    
    def _extract_skeleton(self, binary: np.ndarray) -> np.ndarray:
        """
        骨架提取 - 使用Zhang-Suen细化算法
        
        Args:
            binary: 二值化图像
            
        Returns:
            骨架图像
        """
        # 确保墨迹为白色（1），背景为黑色（0）
        if np.mean(binary) > 127:
            # 白色背景，黑色墨迹 -> 反转
            img = (255 - binary) // 255
        else:
            img = binary // 255
        
        # 使用OpenCV的形态学细化
        skeleton = np.zeros(img.shape, dtype=np.uint8)
        temp = np.zeros(img.shape, dtype=np.uint8)
        element = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
        
        while True:
            # 腐蚀
            eroded = cv2.erode(img, element)
            # 膨胀
            dilated = cv2.dilate(eroded, element)
            # 减去
            temp = cv2.subtract(img, dilated)
            # 或运算
            skeleton = cv2.bitwise_or(skeleton, temp)
            img = eroded.copy()
            
            if cv2.countNonZero(img) == 0:
                break
        
        return skeleton * 255
    
    def _detect_branch_points(self, skeleton: np.ndarray) -> List[Tuple[int, int]]:
        """
        检测骨架分支点（笔画交叉点）
        
        Args:
            skeleton: 骨架图像
            
        Returns:
            分支点坐标列表
        """
        branch_points = []
        h, w = skeleton.shape
        
        # 骨架二值化
        skel = (skeleton > 0).astype(np.uint8)
        
        for y in range(1, h - 1):
            for x in range(1, w - 1):
                if skel[y, x] == 1:
                    # 计算3x3邻域中的邻居数
                    neighbors = np.sum(skel[y-1:y+2, x-1:x+2]) - 1
                    # 分支点有3个或更多邻居
                    if neighbors >= 3:
                        branch_points.append((x, y))
        
        return branch_points
    
    def _detect_end_points(self, skeleton: np.ndarray) -> List[Tuple[int, int]]:
        """
        检测骨架端点
        
        Args:
            skeleton: 骨架图像
            
        Returns:
            端点坐标列表
        """
        end_points = []
        h, w = skeleton.shape
        
        # 骨架二值化
        skel = (skeleton > 0).astype(np.uint8)
        
        for y in range(1, h - 1):
            for x in range(1, w - 1):
                if skel[y, x] == 1:
                    # 计算3x3邻域中的邻居数
                    neighbors = np.sum(skel[y-1:y+2, x-1:x+2]) - 1
                    # 端点只有1个邻居
                    if neighbors == 1:
                        end_points.append((x, y))
        
        return end_points
    
    def _score_structure_advanced(self, features: Dict[str, float]) -> int:
        """
        评分：结构（字形匀称、凸包矩形度、留白分布）
        
        Args:
            features: 特征字典
            
        Returns:
            结构评分
        """
        min_score, max_score = self.score_range
        score_range = max_score - min_score
        
        # 1. 凸包矩形度评分（紧凑度）
        rect_score = features.get("convex_rectangularity", 0.5)
        # 理想值约0.7-0.9
        rect_deviation = abs(rect_score - 0.8)
        rect_normalized = max(0, 1 - rect_deviation * 2)
        
        # 2. 留白均匀性评分
        whitespace_var = features.get("whitespace_variance", 0.1)
        # 方差越小越均匀，理想值接近0
        whitespace_score = max(0, 1 - whitespace_var * 5)
        
        # 3. 投影分布均匀性
        h_proj_std = features.get("h_proj_std", 1)
        v_proj_std = features.get("v_proj_std", 1)
        proj_uniformity = 1 - (h_proj_std + v_proj_std) / 4
        proj_uniformity = max(0, min(1, proj_uniformity))
        
        # 4. 墨迹占比合理性
        ink_ratio = features.get("ink_ratio", 0.15)
        ideal_ratio = 0.15
        ratio_score = 1 - abs(ink_ratio - ideal_ratio) / ideal_ratio
        ratio_score = max(0, min(1, ratio_score))
        
        # 综合评分（加权平均）
        weights = {
            "rect": 0.25,
            "whitespace": 0.3,
            "projection": 0.25,
            "ratio": 0.2
        }
        
        final_score = (
            rect_normalized * weights["rect"] +
            whitespace_score * weights["whitespace"] +
            proj_uniformity * weights["projection"] +
            ratio_score * weights["ratio"]
        )
        
        return int(final_score * score_range + min_score)
    
    def _score_stroke_advanced(self, features: Dict[str, float], binary: np.ndarray) -> int:
        """
        评分：笔画（骨架分析、边缘复杂度）
        
        Args:
            features: 特征字典
            binary: 二值化图像
            
        Returns:
            笔画评分
        """
        min_score, max_score = self.score_range
        score_range = max_score - min_score
        
        # 1. 边缘复杂度（笔画丰富度）
        edge_density = features.get("edge_density", 0.05)
        ideal_density = 0.08
        density_score = 1 - abs(edge_density - ideal_density) / ideal_density
        density_score = max(0, min(1, density_score))
        
        # 2. 骨架分析（笔画连贯性）
        skeleton_length = features.get("skeleton_length", 0)
        ink_count = np.sum(binary == 0)
        
        if ink_count > 0:
            # 骨架与墨迹的比例（反映笔画粗细均匀性）
            skeleton_ratio = skeleton_length / ink_count
            ideal_skeleton_ratio = 0.3
            skeleton_score = 1 - abs(skeleton_ratio - ideal_skeleton_ratio) / ideal_skeleton_ratio
            skeleton_score = max(0, min(1, skeleton_score))
        else:
            skeleton_score = 0.5
        
        # 3. 笔画交叉点（复杂汉字应有的特征）
        branch_count = features.get("branch_point_count", 0)
        # 适当的交叉点数量表示笔画完整
        if branch_count >= 2 and branch_count <= 10:
            branch_score = 1.0
        elif branch_count < 2:
            branch_score = 0.7
        else:
            branch_score = max(0.5, 1 - (branch_count - 10) * 0.05)
        
        # 4. 连通性评分
        components = features.get("num_components", 1)
        if components <= 1:
            connectivity_score = 1.0
        elif components <= 3:
            connectivity_score = 0.85
        elif components <= 5:
            connectivity_score = 0.7
        else:
            connectivity_score = 0.5
        
        # 综合评分
        weights = {
            "density": 0.25,
            "skeleton": 0.25,
            "branch": 0.2,
            "connectivity": 0.3
        }
        
        final_score = (
            density_score * weights["density"] +
            skeleton_score * weights["skeleton"] +
            branch_score * weights["branch"] +
            connectivity_score * weights["connectivity"]
        )
        
        return int(final_score * score_range + min_score)
    
    def _score_balance_advanced(self, features: Dict[str, float]) -> int:
        """
        评分：平衡（精确重心计算、中轴线偏移）
        
        Args:
            features: 特征字典
            
        Returns:
            平衡评分
        """
        min_score, max_score = self.score_range
        score_range = max_score - min_score
        
        # 1. 重心偏移量（PDF公式计算）
        center_offset = features.get("center_offset", 0)
        # 偏移量越小越好，理想值接近0
        balance_score = 1 - center_offset * 3  # 放大偏移影响
        balance_score = max(0, min(1, balance_score))
        
        # 2. 水平对称性
        h_symmetry = features.get("h_symmetry", 0.5)
        
        # 3. 垂直对称性
        v_symmetry = features.get("v_symmetry", 0.5)
        
        # 4. 重心坐标细分分析
        center_x = features.get("center_x", 0.5)
        center_y = features.get("center_y", 0.5)
        
        # X方向偏移（左右平衡）
        x_deviation = abs(center_x - 0.5)
        x_balance = 1 - x_deviation * 2
        
        # Y方向偏移（上下平衡）
        y_deviation = abs(center_y - 0.5)
        y_balance = 1 - y_deviation * 2
        
        # 综合评分
        weights = {
            "center_offset": 0.35,
            "h_symmetry": 0.15,
            "v_symmetry": 0.15,
            "x_balance": 0.175,
            "y_balance": 0.175
        }
        
        final_score = (
            balance_score * weights["center_offset"] +
            h_symmetry * weights["h_symmetry"] +
            v_symmetry * weights["v_symmetry"] +
            x_balance * weights["x_balance"] +
            y_balance * weights["y_balance"]
        )
        
        return int(final_score * score_range + min_score)
    
    def _score_rhythm_advanced(self, features: Dict[str, float]) -> int:
        """
        评分：韵律（行笔流畅度、连通性）
        
        Args:
            features: 特征字典
            
        Returns:
            韵律评分
        """
        min_score, max_score = self.score_range
        score_range = max_score - min_score
        
        # 1. 最大连通分量占比（主体笔画连贯性）
        max_component = features.get("max_component_ratio", 0.5)
        rhythm_score = min(1, max_component)
        
        # 2. 连通分量数量（碎片化程度）
        components = features.get("num_components", 10)
        if components <= 1:
            flow_score = 1.0
        elif components <= 2:
            flow_score = 0.9
        elif components <= 4:
            flow_score = 0.75
        elif components <= 6:
            flow_score = 0.6
        else:
            flow_score = 0.4
        
        # 3. 端点数量（笔画起收点）
        end_points = features.get("end_point_count", 0)
        # 合理的端点数量
        if end_points >= 2 and end_points <= 8:
            endpoint_score = 1.0
        elif end_points < 2:
            endpoint_score = 0.8
        else:
            endpoint_score = max(0.5, 1 - (end_points - 8) * 0.05)
        
        # 4. 骨架长度与墨迹比例（笔画流畅度）
        skeleton_length = features.get("skeleton_length", 0)
        branch_points = features.get("branch_point_count", 0)
        
        # 骨架应该有一定的长度且交叉点适量
        if skeleton_length > 0 and branch_points > 0:
            smoothness = min(1, skeleton_length / (branch_points * 50 + 100))
        else:
            smoothness = 0.5
        
        # 综合评分
        weights = {
            "max_component": 0.3,
            "flow": 0.3,
            "endpoint": 0.2,
            "smoothness": 0.2
        }
        
        final_score = (
            rhythm_score * weights["max_component"] +
            flow_score * weights["flow"] +
            endpoint_score * weights["endpoint"] +
            smoothness * weights["smoothness"]
        )
        
        return int(final_score * score_range + min_score)
    
    def _generate_feedback(self, total_score: int, detail_scores: Dict[str, int]) -> str:
        """
        生成反馈文案
        
        Args:
            total_score: 总分
            detail_scores: 四维评分
            
        Returns:
            反馈文本
        """
        templates = FEEDBACK_TEMPLATES
        excellent_threshold = self.config["excellent_threshold"]
        good_threshold = self.config["good_threshold"]
        
        if total_score >= excellent_threshold:
            # 优秀评价
            feedback = random.choice(templates["excellent"])
        elif total_score >= good_threshold:
            # 良好评价 + 改进建议
            # 找出最低分维度
            min_dim = min(detail_scores, key=detail_scores.get)
            suggestion = templates["good"].get(min_dim, "继续练习，保持进步！")
            feedback = f"良好！{suggestion}"
        else:
            # 需加强练习
            feedback = random.choice(templates["needs_work"])
            
        return feedback


# 创建全局服务实例
evaluation_service = EvaluationService()